import torch
import cv2
import numpy as np

# Leemos la red neuronal realizada
model = torch.hub.load('ultralytics/yolov5', 'custom',path= 'C:/Users/User/Desktop/Red/modelo/best.pt')
cap = cv2.VideoCapture(1)

while True:
# Realizamos lectura de frames
    ret, frame = cap.read()
#detectamos los frames
    detect = model(frame)

    info = detect.pandas().xyxy[0]
    print(info)
    # genera la deteccion con un retraso de 5 milisegundos
    t = cv2.waitKey(5)
    if t == 27:
        break

cap.release()
cv2.destroyAllWindows()


#se debe instalar las depencias para el funcinamiento de la red neuronal
#pip install -r https://raw.githubusercontent.com/ultralytics/yolov5/master/requirements.txt

